import Uploader from './Uploader'

export default Uploader
